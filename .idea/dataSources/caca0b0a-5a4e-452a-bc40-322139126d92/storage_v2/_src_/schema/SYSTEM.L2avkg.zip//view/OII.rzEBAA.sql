create view OII as
select empno,dept from emp
/

