create procedure raise_commission

is
begin
update salesman set commission=commission+2;
commit;
end raise_commission;
/

